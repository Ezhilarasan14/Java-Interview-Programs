﻿var myApp = angular.module('shoppingCart', ['ngRoute','cart','checkout']);

myApp.config(function ($routeProvider) {

    $routeProvider.otherwise({ redirectTo: '/cart' });
});



