﻿var myApp = angular.module('end', ['ngRoute', 'ui.bootstrap']);

myApp.config(function ($routeProvider) {
    $routeProvider.when('/end', {
        templateUrl: 'template/endPage.html',
        controller: 'endPageCtrl'
    });
});

myApp.controller('endPageCtrl', function ($scope, $location, showDivFactory) {

    //Starting the quiz
    $scope.quizStart = function () {
        showDivFactory.setShowQuesDiv(false);
        showDivFactory.setShowPageNoDiv(false);
        showDivFactory.setScore(0);
        $location.path("/welcome");
    };

    $scope.init = function () {
        $scope.score = showDivFactory.getScore();
        $scope.total = showDivFactory.getTotalQuestions();
        if ($scope.score == 0) {
            $scope.message = "Oooops!!! Better Luck Next Time!";
        }
        else if ($scope.score == $scope.total) {
            $scope.message = "Hurray You Are Awesome !!!";
        }
        else if ($scope.score != $scope.total) {
            $scope.message = "Hard Luck !!! Once More";
        }
        
    };

    $scope.checkReload = function () {
        //check for navigation time API support
        if (window.performance) {
            //console.info("window.performance work's fine on this browser");
        }
        if (performance.navigation.type == 1) {
            $location.path("/welcome");
        } else {
            //console.info("This page is not reloaded");
        }
    }

    $scope.init();
    $scope.checkReload();

});