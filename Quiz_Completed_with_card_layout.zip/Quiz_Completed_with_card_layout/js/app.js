﻿var myApp = angular.module('QApp', ['ngRoute', 'ui.bootstrap', 'welcome', 'quiz2', 'quiz3','end']);

myApp.config(function ($routeProvider) {

    $routeProvider.otherwise({ redirectTo: '/welcome' });
});

myApp.factory('showDivFactory', function () {
    var showQuesDiv = true;

    var showPageNoDiv = false;

    var score = 0;

    var totalQuestions = 0;

    var refreshCounter = 0;

    return {
        setShowQuesDiv: function (value) {
            showQuesDiv = value;
        },

        getShowQuesDiv: function () {
            return showQuesDiv;
        },

        setShowPageNoDiv: function (value) {
            showPageNoDiv = value;
        },

        getShowPageNoDiv: function () {
            return showPageNoDiv;
        },

        setScore: function (value) {
            score = value;
        },

        getScore: function () {
            return score;
        },

        setTotalQuestions: function (value) {
            totalQuestions = value;
        },

        getTotalQuestions: function () {
            return totalQuestions;
        },

        getShowQuestion: function () {
            return 1;
        },

        setRefreshCounter: function () {
            refreshCounter++;
        },

        getRefreshCounter: function () {
            return refreshCounter;
        }
    };
});






