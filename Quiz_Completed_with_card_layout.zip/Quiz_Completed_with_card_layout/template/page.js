﻿var myApp = angular.module('page', ['ngRoute', 'ui.bootstrap']);

myApp.config(function ($routeProvider) {
    $routeProvider.when('/page', {
        templateUrl: 'template/page.html',
        controller: 'pageCtrl'
    });
});

myApp.controller('pageCtrl', function ($scope) {
    $scope.filteredTodos = []
  , $scope.currentPage = 1
  , $scope.numPerPage = 7
  , $scope.maxSize = 5;


    $scope.makeTodos = function () {
        $scope.todos = []
        for (i = 1; i <= 28; i++) {
            $scope.todos.push({ text: 'todo ' + i, done: false });
        }
    };

    $scope.makeTodos();

    $scope.$watch('currentPage + numPerPage', function () {
        var begin = (($scope.currentPage - 1) * $scope.numPerPage)
    , end = begin + $scope.numPerPage;

        $scope.filteredTodos = $scope.todos.slice(begin, end);
    });

});

myApp.factory('quizFactory', function () {
    var questions = [
		{
		    question: "Which is the largest country in the world by population?",
		    options: ["India", "USA", "China", "Russia"],
		    answer: 2
		},
		{
		    question: "When did the second world war end?",
		    options: ["1945", "1939", "1944", "1942"],
		    answer: 0
		},
		{
		    question: "Which was the first country to issue paper currency?",
		    options: ["USA", "France", "Italy", "China"],
		    answer: 3
		},
		{
		    question: "Which city hosted the 1996 Summer Olympics?",
		    options: ["Atlanta", "Sydney", "Athens", "Beijing"],
		    answer: 0
		},
		{
		    question: "Who invented telephone?",
		    options: ["Albert Einstein", "Alexander Graham Bell", "Isaac Newton", "Marie Curie"],
		    answer: 1
		},
        {
            question: "Which city hosted the 1996 Summer Olympics?",
            options: ["Atlanta", "Sydney", "Athens", "Beijing"],
            answer: 0
        },
		{
		    question: "Who invented telephone?",
		    options: ["Albert Einstein", "Alexander Graham Bell", "Isaac Newton", "Marie Curie"],
		    answer: 1
		},
		{
		    question: "Which was the first country to issue paper currency?",
		    options: ["USA", "France", "Italy", "China"],
		    answer: 3
		},
		{
		    question: "Which city hosted the 1996 Summer Olympics?",
		    options: ["Atlanta", "Sydney", "Athens", "Beijing"],
		    answer: 0
		},
		{
		    question: "Who invented telephone?",
		    options: ["Albert Einstein", "Alexander Graham Bell", "Isaac Newton", "Marie Curie"],
		    answer: 1
		}
	];

    return {
        getQuestion: function (id) {
            if (id < questions.length) {
                return questions[id];
            } else {
                return false;
            }
        },

        getAllQuestion: function () {
            return questions;
        }
    };
});
