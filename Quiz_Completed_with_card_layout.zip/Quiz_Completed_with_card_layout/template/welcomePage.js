﻿var myApp = angular.module('welcome', ['ngRoute', 'ui.bootstrap']);

myApp.config(function ($routeProvider) {
    $routeProvider.when('/welcome', {
        templateUrl: 'template/welcomePage.html',
        controller: 'welcomePageCtrl'
    });
});

myApp.controller('welcomePageCtrl', function ($scope, $location, showDivFactory) {

    //Starting the quiz
    $scope.quizStart = function () {
        showDivFactory.setShowQuesDiv(true);
        showDivFactory.setShowPageNoDiv(true);
        $location.path("/quiz2");
    }

});