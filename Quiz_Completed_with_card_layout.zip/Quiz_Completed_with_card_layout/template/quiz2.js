﻿var myApp = angular.module('quiz2', ['ngRoute', 'ui.bootstrap']);

myApp.config(function ($routeProvider) {
    $routeProvider.when('/quiz2', {
        templateUrl: 'template/quiz2.html',
        controller: 'quiz2Ctrl'
    });
});

myApp.controller('quiz2Ctrl', function ($scope, quesFactory, showDivFactory, $location) {

    $scope.quizOverDiv = false;
    $scope.flag = 0;
    $scope.pageNo = [];
    $scope.errorMessage = "";
    $scope.lastQuestionFlag = false;
    $scope.score = 0;
    $scope.questionStatusDiv = false;

    $scope.quizStart = function () {
        $scope.showQuesDiv = showDivFactory.getShowQuesDiv();
        $scope.showPageNoDiv = showDivFactory.getShowPageNoDiv();
        $scope.showQuestion(showDivFactory.getShowQuestion());
        $scope.allQuestion.forEach(function (question) {
            question.status = "Not Attempted";
        });
        showDivFactory.setTotalQuestions($scope.allQuestion.length);

    };

    //Setting page numbers
    $scope.allQuestion = quesFactory.getAllQuestion();

    for (var i = 1; i <= $scope.allQuestion.length; i++) {
        $scope.pageNo[i - 1] = i;
    }

    //Showing question as per page number
    $scope.showQuestion = function (pageNo) {
        $scope.questionStatusDiv = false;
        $scope.questionArr = quesFactory.getQuestion(pageNo - 1);
        $scope.showQuesDiv = true;
        $scope.errorMessage = "";
        if (pageNo === $scope.allQuestion.length) {
            $scope.lastQuestionFlag = true;
        }

        if(true)
        $("chkBox").attr("disabled", true);
    };

    

    //Validating Answer when submitted
    $scope.checkAnswer = function () {
        if ($scope.questionArr.status === "Not Attempted") {
            if (!$('input[name=answer]:checked').length) return;

            var ans = $('input[name=answer]:checked').val();
            if (ans == $scope.questionArr.options[$scope.questionArr.answer].name) {
                $scope.score++;
                $scope.errorMessage = "Correct Answer";
                $scope.questionArr.options
            }
            else {
                $scope.errorMessage = "Incorrect Answer";
                $("input[name=answer]").attr("disabled", true);
            }

            //Saving the current selection in factory
            for (var i = 0; i < $scope.questionArr.options.length; i++) {
                if (ans == $scope.questionArr.options[i].name) {
                    $scope.questionArr.options[i].selected = true;
                }
            }

            $scope.questionArr.status = "Attempted";
        }
        else {
            $scope.errorMessage = "The question has been already Attempted"
        }
    };

    $scope.quizOver = function () {
        showDivFactory.setScore($scope.score);
        $location.path("/end");
    };

    $scope.reviewStatus = function () {
        $scope.questionStatusDiv = true;
    }

    $scope.statusDivBackBtn = function () {
        $scope.questionStatusDiv = false;
    }

    $scope.checkReload = function () {
        //check for navigation time API support
        /*if (window.performance) {
        console.info("window.performance work's fine on this browser");
        console.log(performance.navigation.type);
        }*/
        if (performance.navigation.type == 1) {
            showDivFactory.setScore($scope.score);
            $location.path("/end");
            if (showDivFactory.getRefreshCounter() == 0) {
                showDivFactory.setRefreshCounter();
                alert("Refresh button pressed. The Quiz will end!!!")
            }

        } else {
            //console.info("This page is not reloaded");
        }
    }


    $scope.quizStart();

    $scope.checkReload();
});

myApp.factory('quesFactory', function () {
    var questions = [
		{
		    question: "Which is the second largest country in the world by population?",
		    options: [{ name: 'India',    selected: false },
                      { name: 'USA',   selected: false },
                      { name: 'China',     selected: false },
                      { name: 'Russia', selected: false }],
		    answer: 0,
            status:"Not Attempted"
        },
		{
		    question: "When did the second world war end?",
		    options: [{ name: '1945', selected: false },
                      { name: '1939', selected: false },
                      { name: '1944', selected: false },
                      { name: '1942', selected: false }],
		    answer: 0,
		    status: "Not Attempted"
		},
		{
		    question: "Which was the first country to issue paper currency?",
		    options:  [{ name: 'USA', selected: false },
                      { name: 'France', selected: false },
                      { name: 'Italy', selected: false },
                      { name: 'China', selected: false }],
		    answer: 3,
		    status: "Not Attempted"
		},
		{
		    question: "Which city hosted the 1996 Summer Olympics?",
		    options:  [{ name: 'Atlanta', selected: false },
                      { name: 'Sydney', selected: false },
                      { name: 'Athens', selected: false },
                      { name: 'Beijing', selected: false }],
		    answer: 0,
		    status: "Not Attempted"
		},
		{
		    question: "Who invented Radium?",
		    options:  [{ name: "Albert Einstein", selected: false },
                      { name: "Alexander Graham Bell", selected: false },
                      { name: "Isaac Newton", selected: false },
                      { name: "Marie Curie", selected: false }],
		    answer: 3,
		    status: "Not Attempted"
		}
	];

    return {
        getQuestion: function (id) {
            if (id < questions.length) {
                return questions[id];
            } else {
                return false;
            }
        },

        getAllQuestion: function () {
            return questions;
        }
    };
});