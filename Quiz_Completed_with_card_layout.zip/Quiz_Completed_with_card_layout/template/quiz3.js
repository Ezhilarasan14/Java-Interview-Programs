﻿var myApp = angular.module('quiz3', ['ngRoute']);

myApp.config(function ($routeProvider) {
    $routeProvider.when('/quiz3', {
        templateUrl: 'template/quiz3.html',
        controller: 'quiz3Ctrl'
    });
});

myApp.controller('quiz3Ctrl', function ($scope, quizFactory) {


    $scope.start = function () {
        $scope.id = 0;
        $scope.quizOver = false;
        $scope.inProgress = true;
        $scope.errorMessage = "";
        $scope.submitBtn = "Submit";
        $scope.getQuestion();
        $scope.flag = 0;
    };

    $scope.reset = function () {
        $scope.inProgress = false;
        $scope.score = 0;

    }

    $scope.getQuestion = function () {
        var q = quizFactory.getQuestion($scope.id);
        if (q) {
            $scope.question = q.question;
            $scope.options = q.options;
            $scope.answer = q.answer;
            $scope.answerMode = true;
        } else {
            $scope.quizOver = true;
        }
    };

    $scope.checkAnswer = function () {

        if ($scope.flag === 0) {
            if (!$('input[name=answer]:checked').length) return;

            var ans = $('input[name=answer]:checked').val();

            if (ans == $scope.options[$scope.answer]) {
                $scope.score++;
                $scope.errorMessage = "Correct Answer";
                $scope.submitBtn = "Next";
            } else {
                $scope.errorMessage = "Incorrect Answer";
                $scope.submitBtn = "Next";
            }
            $scope.flag++;
            $scope.answerMode = false;
        } 
        else if ($scope.flag > 0) {
            $scope.nextQuestion();
            $scope.flag = 0;
        }
    };

    $scope.nextQuestion = function () {
        $scope.id++;
        $scope.getQuestion();
        $scope.submitBtn = "Submit";
    }

    $scope.prevQuestion = function () {
        if ($scope.id === 0) {
            $scope.errorMessage = "First Question";
        } else {
            $scope.id--;
            $scope.getQuestion();
        }

    }

    $scope.reset();

});

myApp.factory('quizFactory', function () {
    var questions = [
		{
		    question: "Which is the largest country in the world by population?",
		    options: ["India", "USA", "China", "Russia"],
		    answer: 2,
            marked: -1
		},
		{
		    question: "When did the second world war end?",
		    options: ["1945", "1939", "1944", "1942"],
		    answer: 0,
		    marked: -1
		},
		{
		    question: "Which was the first country to issue paper currency?",
		    options: ["USA", "France", "Italy", "China"],
		    answer: 3,
		    marked: -1
		},
		{
		    question: "Which city hosted the 1996 Summer Olympics?",
		    options: ["Atlanta", "Sydney", "Athens", "Beijing"],
		    answer: 0,
		    marked: -1
		},
		{
		    question: "Who invented telephone?",
		    options: ["Albert Einstein", "Alexander Graham Bell", "Isaac Newton", "Marie Curie"],
		    answer: 1,
		    marked: -1
		}
	];

    return {
        getQuestion: function (id) {
            if (id < questions.length) {
                return questions[id];
            } else {
                return false;
            }
        }
    };
});