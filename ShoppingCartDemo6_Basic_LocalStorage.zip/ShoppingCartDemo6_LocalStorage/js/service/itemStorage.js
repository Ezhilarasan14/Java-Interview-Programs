﻿angular.module('myApp')
    .factory('itemStorage', function ($http, $injector) {
		'use strict';
		return $injector.get('localStorage');
	})

    .factory('localStorage', function ($q) {
		'use strict';

		var STORAGE_ID = 'name-angularjs';

		var store = {
			items: [],

			_getFromLocalStorage: function () {
				return JSON.parse(localStorage.getItem(STORAGE_ID) || '[]');
			},

			_saveToLocalStorage: function (items) {
				localStorage.setItem(STORAGE_ID, JSON.stringify(items));
			},
			
			//Deletes the task
			delete: function (item) {
				var deferred = $q.defer();

				store.items.splice(store.items.indexOf(item), 1);

				store._saveToLocalStorage(store.items);
				deferred.resolve(store.items);

				return deferred.promise;
			},

			//Called when the page is loaded, it loads the tasks from LocalStorage
			get: function () {
				var deferred = $q.defer();

				angular.copy(store._getFromLocalStorage(), store.items);
				deferred.resolve(store.items);

				return deferred.promise;
			},

			
			//Adds the elements into the Store object
			insert: function (item) {
				var deferred = $q.defer();

				store.items.push(item);

				store._saveToLocalStorage(store.items);
				deferred.resolve(store.items);

				return deferred.promise;
			}
		};

		return store;
	});