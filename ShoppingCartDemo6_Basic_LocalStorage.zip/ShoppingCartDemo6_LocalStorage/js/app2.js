﻿var myApp = angular.module('myApp', []);

myApp.controller('myController', function ($scope, localStorage) {
    
    //Called to load the data from localStorage into items var in itemStorage file
    localStorage.get();

    //Copy the data from localStorage-items into local items var which is used to display data in table
    var items = $scope.items = localStorage.items;
    
    //Used to connect to model in html file
    $scope.item='';

    //Called when save btn in clicked
    $scope.save = function(){

        var newItem = {
    			name: $scope.item.name.trim(),
				price: $scope.item.price.trim()								
			};

        localStorage.insert(newItem)
				.then(function success() {
					$scope.item = '';
				})
				.finally(function () {
					$scope.message = "New Item Added Successfully!";
					$scope.saving = false;
				});
    };


    $scope.delete = function(item){
        localStorage.delete(item);
	    $scope.message = "Item Deleted Successfully!";
    };

});


