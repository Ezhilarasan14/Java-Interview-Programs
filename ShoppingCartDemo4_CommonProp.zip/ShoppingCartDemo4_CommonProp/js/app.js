﻿var myApp = angular.module('shoppingCart', ['ngRoute','cart','checkout']);

myApp.config(function ($routeProvider) {
//    $routeProvider.when('/cart', {
//        templateUrl: 'cart/cart.html',
//        controller: 'cartCtrl'
//    });

    $routeProvider.otherwise({ redirectTo: '/cart' });
});

//myApp.controller('cartCtrl', function ($scope) {
//    
//});

//myApp.controller('productCtrl', ['$scope', '$http', 'ngCart', '$location', function ($scope, $http, ngCart, $location) {
//    ngCart.setTaxRate(7.5);
//    ngCart.setShipping(2.99);

//    $scope.gotoCart = function (token) {
//        if (token === 'cart') {
//            $location.path('/cart');
//        }
//        else if (token === 'checkout') {
//            $location.path('/checkout');
//        }

//    }

//} ]);


//myApp.controller('addtocartCtrl', ['$scope', '$http', 'ngCart', function ($scope, $http, ngCart) {

//} ]);

