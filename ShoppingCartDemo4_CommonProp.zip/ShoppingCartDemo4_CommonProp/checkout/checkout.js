﻿var myApp = angular.module('checkout', ['ngRoute']);

myApp.config(function ($routeProvider) {
    $routeProvider.when('/checkout', {
        templateUrl: 'checkout/checkout.html',
        controller: 'checkoutCtrl'
    });
});

myApp.controller('checkoutCtrl', function ($scope, CommonProp) {
    $scope.selectedItems = CommonProp.getItems();
    $scope.checkoutTotal = CommonProp.getTotal();
});