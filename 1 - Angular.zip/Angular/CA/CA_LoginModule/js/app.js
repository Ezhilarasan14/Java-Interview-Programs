
var app = angular.module("caApp", ["ngRoute"])

            .config(function ($routeProvider, $locationProvider) {
                $routeProvider
                .when("/login", {
                    templateUrl: "modules/login.html",
                    controller: "loginController"
                })

            .when("/courses", {
                templateUrl: "Templates/courses.html",
                controller: "coursesController"
            })


            .otherwise({
                redirectTo: "/login" 
            })
            //$locationProvider.html5Mode(true);
            })



        .controller("loginController", function ($scope) {
            $scope.message = "Login Page";
			
        })

        .controller("coursesController", function ($scope) {
            $scope.courses = ["C#", "CPP", "Java", "MySQL", "HTML", "Angular"];
        })
