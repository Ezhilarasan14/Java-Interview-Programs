	var app = angular.module('store', ['ngCookies']);

	app.controller('StoreController', ['$scope','$cookies','$rootScope', function($scope,$cookies,$rootScope){
	var productsData = [{
		id: 1,
		name: 'product1',
		price: 100.0,
		image: ''
	},{
		id: 2,
		name: 'product2',
		price: 14.5,
		image: ''
	},{
		id: 3,
		name: 'product3',
		price: 100.43,
		image: ''
	},{
		id: 4,
		name: 'product4',
		price: 99.9,
		image: ''
	}];
		
		
		$scope.products = productsData;
		$rootScope.cart = [];
		$scope.total = 0;
	  
		if(!angular.isUndefined($cookies.get('total'))){
		  $scope.total = parseFloat($cookies.get('total'));
		}
		
		if (!angular.isUndefined($cookies.get('cart'))) {
		 		$rootScope.cart =  $cookies.getObject('cart');
		}
		
		$scope.addItemToCart = function(product){
		  
		 	if ($rootScope.cart.length === 0){
		 		product.count = 1;
		 		$rootScope.cart.push(product);
		 	} else {
		 		var repeat = false;
		 		for(var i = 0; i< $rootScope.cart.length; i++){
		 			if($rootScope.cart[i].id === product.id){
		 				repeat = true;
		 				$rootScope.cart[i].count +=1;
		 			}
		 		}
		 		if (!repeat) {
		 			product.count = 1;
		 		 	$rootScope.cart.push(product);	
		 		}
		 	}
		 	var expireDate = new Date();
      expireDate.setDate(expireDate.getDate() + 1);
		 	$cookies.putObject('cart', $rootScope.cart,  {'expires': expireDate});
		 	$rootScope.cart = $cookies.getObject('cart');
		 
		  $scope.total += parseFloat(product.price);
		$cookies.put('total', $scope.total,  {'expires': expireDate});
		 };

		 $scope.removeItemCart = function(product){
		   
		   if(product.count > 1){
		     product.count -= 1;
		     var expireDate = new Date();
         expireDate.setDate(expireDate.getDate() + 1);
		     $cookies.putObject('cart', $rootScope.cart, {'expires': expireDate});
 			   $rootScope.cart = $cookies.getObject('cart');
		   }
		   else if(product.count === 1){
		     var index = $rootScope.cart.indexOf(product);
 			 $rootScope.cart.splice(index, 1);
 			 expireDate = new Date();
       expireDate.setDate(expireDate.getDate() + 1);
 			 $cookies.putObject('cart', $rootScope.cart, {'expires': expireDate});
 			 $rootScope.cart = $cookies.getObject('cart');
		     
		   }
		   
		   $scope.total -= parseFloat(product.price);
       $cookies.put('total', $scope.total,  {'expires': expireDate});
		   
		 };

	}]);

	
