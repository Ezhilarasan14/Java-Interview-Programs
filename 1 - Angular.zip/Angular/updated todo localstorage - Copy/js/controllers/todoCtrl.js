
angular.module('todomvc')
	.controller('TodoCtrl', function TodoCtrl($scope, $routeParams, $filter, store) {
		'use strict';

		var todos = $scope.todos = store.todos;

		$scope.newTodo = '';
		$scope.message = "";
		$scope.cart = todos;
		
		var itemsList = {
			item1 = {
				itemName: "Mouse",
				price: "10",
				quantity: '1'
			},
			
			item2 = {
				itemName: "keyboard",
				price: "50",
				quantity: '1'
				
			},
		}

		
		//Called when a new task is entered and enter is pressed
		$scope.addTodo = function () {
			var newTodo = {
				itemName: $scope.newTodo.itemName.trim(),
				price: $scope.newTodo.price.trim(),
				quantity: $scope.newTodo.quantity.trim()
				
			};

			if (!newTodo.itemName) {
				return;
			}

			$scope.saving = true;
			store.insert(newTodo)
				.then(function success() {
					$scope.newTodo = '';
				})
				.finally(function () {
					$scope.message = "New Item Added Successfully!";
					$scope.saving = false;
				});
		};


		//Called when a task is deleted
		$scope.removeTodo = function (todo) {
			store.delete(todo);
			$scope.message = "Item Deleted Successfully!";
		};

		$scope.clearMessage = function(){
			$scope.message = "";
		};
	});
