﻿var myApp = angular.module('shoppingCart', ['ngRoute', 'home', 'itemPage1', 'cart', 'itemPage2', 'itemPage3', 'itemPage4', 'checkoutStart']);

myApp.config(function ($routeProvider) {

    $routeProvider.otherwise({ redirectTo: '/home' });
});



