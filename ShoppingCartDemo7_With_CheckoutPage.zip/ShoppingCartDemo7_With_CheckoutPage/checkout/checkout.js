﻿var myApp = angular.module('checkout', ['ngRoute']);

myApp.config(function ($routeProvider) {
    $routeProvider.when('/checkout', {
        templateUrl: 'checkout/checkout.html',
        controller: 'checkoutCtrl'
    });
});

myApp.controller('checkoutCtrl', function ($scope, localStorage) {

    $scope.$on('$viewContentLoaded', function () {
        localStorage.get();
        $scope.cart = localStorage.items;
        if ($scope.cart.length === 0) {
            $scope.cart = [];
            $scope.cartTotalPrice = 0;
            $scope.cartTotalQty = 0;
        }
        else {
            $scope.total();
        }

    });
    //Calculate total
    $scope.total = function () {
        $scope.cartTotalPrice = 0;
        var cnt = 0;
        for (var k in $scope.cart) {
            $scope.cartTotalPrice += parseInt($scope.cart[k].price * $scope.cart[k].qty);
            cnt += parseInt($scope.cart[k].qty);
        }
        $scope.cartTotalQty = cnt;
        $scope.cartTotalPrice;
    };

    $scope.setQuantity = function (item1, flag) {
        for (item in $scope.cart) {
            if ($scope.cart[item].name === item1.name) {
                if (flag === 1)
                    $scope.cart[item].qty = parseInt(item1.qty) + 1;
                else if (flag === -1 && $scope.cart[item].qty > 1) { 
                    $scope.cart[item].qty = parseInt(item1.qty) - 1;
                }

                //updating localstorage object
                localStorage.update(item)
				.then(function success() {
					
				})
				.finally(function () {
					$scope.saving = false;
				});
            }

            
        }
        $scope.total();
    };

    $scope.remove = function(item1){
        localStorage.delete(item1);
        if(localStorage.items.length != $scope.cart.length){
            $scope.cart.splice($scope.cart.indexOf(item1), 1);
        }
        $scope.total();
    };

});