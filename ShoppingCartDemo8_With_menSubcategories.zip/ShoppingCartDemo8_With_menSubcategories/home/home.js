﻿var myApp = angular.module('home', ['ngRoute']);

myApp.config(function ($routeProvider) {
    $routeProvider.when('/home', {
        templateUrl: 'home/home.html',
        controller: 'homeCtrl'
    });
});

myApp.controller('homeCtrl', function ($scope, $http, localStorage, CommonProp, $location) {

    //Called to load the data from localStorage into items var in itemStorage file
    localStorage.get();

    //Load items from Localstorage, calc total or set default values
    $scope.$on('$viewContentLoaded', function () {
        $scope.cart = localStorage.items;
        if ($scope.cart.length === 0) {
            $scope.cart = [];
            $scope.cartTotalPrice = 0;
            $scope.cartTotalQty = 0;
        }
        else {
            $scope.total();
        }

    });

    $scope.selectedItem = '';
    //Default Items
    $scope.items = [{ name: "Mouse", price: "250", qty: "1", img: "../resources/business.jpg" },
                 { name: "Keyboard", price: "500", qty: "1", img: "../resources/business2.jpg" },
                 { name: "RAM", price: "2000", qty: "1", img: "../resources/business.jpg" },
                 { name: "CPU", price: "5000", qty: "1", img: "../resources/business2.jpg"}];

    $scope.selectItem = function (item) {
        $scope.selectedItem = item;
        CommonProp.setSelectedItems($scope.selectedItem);
        if (item.name === "Mouse") {
            $location.path('/itemPage1');
        }
        else if (item.name === "Keyboard") {
            $location.path('/itemPage2');
        }
        else if (item.name === "RAM") {
            $location.path('/itemPage3');
        }
        else if (item.name === "CPU") {
            $location.path('/menSubCategoriesSelect');
        }
    };

    //Calculate total
    $scope.total = function () {
        $scope.cartTotalPrice = 0;
        var cnt = 0;
        for (var k in $scope.cart) {
            $scope.cartTotalPrice += parseInt($scope.cart[k].price * $scope.cart[k].qty);
            cnt += parseInt($scope.cart[k].qty);
        }
        $scope.cartTotalQty = cnt;
        return $scope.cartTotalPrice;
    };

});


myApp.service('CommonProp', function () {
    var selectedItems = '';
    //var Total = 0;

    return {
        getSelectedItems: function () {
            return selectedItems;
        },

        setSelectedItems: function (value) {
            selectedItems = value;
        }
    }
})