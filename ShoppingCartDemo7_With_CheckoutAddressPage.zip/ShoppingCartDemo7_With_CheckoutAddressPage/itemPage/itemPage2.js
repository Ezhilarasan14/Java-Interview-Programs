﻿var myApp = angular.module('itemPage2', ['ngRoute']);

myApp.config(function ($routeProvider) {
    $routeProvider.when('/itemPage2', {
        templateUrl: 'itemPage/itemPage2.html',
        controller: 'itemPageCtrl2'
    });
});

myApp.controller('itemPageCtrl2', function ($scope, $http, localStorage) {
        
    //Called to load the data from localStorage into items var in itemStorage file
    localStorage.get();
    $scope.flag = 0;
    
    
    //Load items from Localstorage, calc total or set default values
    $scope.$on('$viewContentLoaded', function() {
        $scope.cart = localStorage.items;
        if($scope.cart.length === 0){
            $scope.cart = [];
            $scope.cartTotalPrice = 0;
            $scope.cartTotalQty = 0;
            $scope.addtocartBtnText = "ADD TO CART";
        }
        else{
            $scope.total();
        }
       
        $scope.disableAddtocartBtn();
        
    });


    $scope.item = { name: "Keyboard", price: "500", qty: "1", img: "../resources/business2.jpg" ,logo:"../resources/business2_150.jpg"};
   
    
    //Function to disable Addtocartbtn (if item already exists in cart) after clicking, 
    //when loading the page, coming back from any other page
    $scope.disableAddtocartBtn = function(){
         for (var k in $scope.cart) {
            if($scope.item.name === $scope.cart[k].name){
                $scope.addtocartBtnText = "ALREADY ADDED";
                $scope.flag = 1;
                $scope.disabled = true;
            }
            else if($scope.flag === 0){
                 $scope.addtocartBtnText = "ADD TO CART";
                 $scope.disabled = false;
            }
        }
    }
   


    //Add items to localstorage & cart, disable the addtocartBtn
    $scope.addtoCart = function (item) {
            //Convert the imgs to base64 then set it to localstorage
            //var bannerImage = document.getElementById('itemImg');
            var bannerImage = document.getElementById('itemLogo');
            item.img = "";
            item.logo = $scope.getBase64Image(bannerImage);
            
            //insert the data into localstorage
            localStorage.insert(item)
				.then(function success() {
					//$scope.item = '';
				})
				.finally(function () {
					$scope.message = "Added to Cart!";
					$scope.saving = false;
				});

                //To avoid duplicates/ multiple entries on single click
                if(localStorage.items.length != $scope.cart.length)
                $scope.cart.push(item);
                $scope.total();
                $scope.disableAddtocartBtn();
                
    };

     //Calculate total
    $scope.total = function () {
        $scope.cartTotalPrice = 0;
        var cnt = 0;
        for (var k in $scope.cart) {
            $scope.cartTotalPrice += parseInt($scope.cart[k].price * $scope.cart[k].qty);
            cnt += parseInt($scope.cart[k].qty);
        }
        $scope.cartTotalQty = cnt;
        return $scope.cartTotalPrice;
    };

    $scope.getBase64Image = function(img) {
        var canvas = document.createElement("canvas");
        canvas.width = img.width;
        canvas.height = img.height;

        var context = canvas.getContext("2d");
        context.drawImage(img, 0, 0);

        var dataURL = canvas.toDataURL();
        return dataURL;
    };
});