﻿var myApp = angular.module('checkoutAddress', ['ngRoute']);

myApp.config(function ($routeProvider) {
    $routeProvider.when('/checkoutAddress', {
        templateUrl: 'checkout/checkoutAddress.html',
        controller: 'checkoutAddressCtrl'
    });
});

myApp.controller('checkoutAddressCtrl', function ($scope, localStorage, $location) {

    $scope.$on('$viewContentLoaded', function () {
        localStorage.get();
        $scope.cart = localStorage.items;
        if ($scope.cart.length === 0) {
            $scope.cart = [];
            $scope.cartTotalPrice = 0;
            $scope.cartTotalQty = 0;
        }
        else {
            $scope.total();
        }

    });

    //Calculate total
    $scope.total = function () {
        $scope.cartTotalPrice = 0;
        var cnt = 0;
        for (var k in $scope.cart) {
            $scope.cartTotalPrice += parseInt($scope.cart[k].price * $scope.cart[k].qty);
            cnt += parseInt($scope.cart[k].qty);
        }
        $scope.cartTotalQty = cnt;
        $scope.cartTotalPrice;
    };

    $scope.email = '';
    $scope.exp = '';

    $scope.saveAddress = function () {
        

        //Call to database to save the new user

        //Call to address page
        //$location.path("/checkoutAddress");
    }

});