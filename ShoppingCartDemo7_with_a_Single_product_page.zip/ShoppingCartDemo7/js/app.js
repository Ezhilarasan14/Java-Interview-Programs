﻿var myApp = angular.module('shoppingCart', ['ngRoute','home','itemPage','cart','checkout']);

myApp.config(function ($routeProvider) {

    $routeProvider.otherwise({ redirectTo: '/home' });
});



