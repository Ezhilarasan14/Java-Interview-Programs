﻿var myApp = angular.module('itemPage', ['ngRoute']);

myApp.config(function ($routeProvider) {
    $routeProvider.when('/itemPage', {
        templateUrl: 'itemPage/itemPage.html',
        controller: 'itemPageCtrl'
    });
});

myApp.controller('itemPageCtrl', function ($scope, $http, localStorage, CommonProp) {
     
    //Called to load the data from localStorage into items var in itemStorage file
    localStorage.get();
     
    //Load items from Localstorage, calc total or set default values
    $scope.$on('$viewContentLoaded', function() {
        $scope.cart = localStorage.items;
        if($scope.cart.length === 0){
            $scope.cart = [];
            $scope.cartTotalPrice = 0;
            $scope.cartTotalQty = 0;
        }
        else
        {
            
        }
        
    });

    $scope.selectedItem = CommonProp.getSelectedItems();

    //Addtocartbtn text
    $scope.addtocartBtnText = "ADD TO CART";


    //Add items
    $scope.addtoCart = function (item) {
            //insert the data into localstorage
            localStorage.insert(item)
				.then(function success() {
					$scope.item = '';
				})
				.finally(function () {
					$scope.message = "Added to Cart!";
					$scope.saving = false;
				});

                //To avoid duplicates/ multiple entries on single click
                if(localStorage.items.length != $scope.cart.length)
                $scope.cart.push(item);
                $scope.total();
                
    };

     //Calculate total
    $scope.total = function () {
        $scope.cartTotalPrice = 0;
        var cnt = 0;
        for (var k in $scope.cart) {
            $scope.cartTotalPrice += parseInt($scope.cart[k].price * $scope.cart[k].qty);
            cnt += parseInt($scope.cart[k].qty);
        }
        $scope.cartTotalQty = cnt;
        return $scope.cartTotalPrice;
    };

});