﻿var myApp = angular.module('cart', ['ngRoute']);

myApp.config(function ($routeProvider) {
    $routeProvider.when('/cart', {
        templateUrl: 'cart/cart.html',
        controller: 'cartCtrl'
    });
});

myApp.controller('cartCtrl', function ($scope, $http, localStorage) {
    
    //Called to load the data from localStorage into items var in itemStorage file
    localStorage.get();
     
    //Load items from Localstorage, calc total or set default values
    $scope.$on('$viewContentLoaded', function() {
        $scope.cart = localStorage.items;
        if($scope.cart.length === 0){
            $scope.cart = [];
            $scope.cartTotalPrice = 0;
            $scope.cartTotalQty = 0;
        }
        else
        {
            $scope.total();
        }
        
    });

    //Addtocartbtn text
    $scope.addtocartBtnText = "ADD TO CART";

    //Default Items
    $scope.items = [{ name: "Mouse", price: "250", qty:"1" },
                 { name: "Keyboard", price: "500", qty:"1" },
                 { name: "RAM", price: "2000", qty:"1" },
                 { name: "CPU", price: "5000", qty:"1"}];


    //Add items
    $scope.addtoCart = function (item) {
            //insert the data into localstorage
            localStorage.insert(item)
				.then(function success() {
					$scope.item = '';
				})
				.finally(function () {
					$scope.message = "Added to Cart!";
					$scope.saving = false;
				});

                //To avoid duplicates/ multiple entries on single click
                if(localStorage.items.length != $scope.cart.length)
                $scope.cart.push(item);
                $scope.total();
    }


    //Calculate total
    $scope.total = function () {
        $scope.cartTotalPrice = 0;
        var cnt = 0;
        for (var k in $scope.cart) {
            $scope.cartTotalPrice += parseInt($scope.cart[k].price * $scope.cart[k].qty);
            cnt += parseInt($scope.cart[k].qty);
        }
        $scope.cartTotalQty = cnt;
        return $scope.cartTotalPrice;
    };

    $scope.removefromCart = function (item) { 
          localStorage.delete(item);
    };

    //Removes all items from cart & localStorage
    $scope.removeAllItems = function(){
        localStorage.deleteAll();
        $scope.cart.length = 0;
        $scope.total();
    };




});