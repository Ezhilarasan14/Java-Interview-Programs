﻿var myApp = angular.module('home', ['ngRoute']);

myApp.config(function ($routeProvider) {
    $routeProvider.when('/home', {
        templateUrl: 'home/home.html',
        controller: 'homeCtrl'
    });
});

myApp.controller('homeCtrl', function ($scope, $http, localStorage, CommonProp, $location) {

    //Called to load the data from localStorage into items var in itemStorage file
    localStorage.get();

    //Load items from Localstorage, calc total or set default values
    $scope.$on('$viewContentLoaded', function () {
        $scope.cart = localStorage.items;
        if ($scope.cart.length === 0) {
            $scope.cart = [];
            $scope.cartTotalPrice = 0;
            $scope.cartTotalQty = 0;
        }
        else {

        }

    });

    $scope.selectedItem = '';
    //Default Items
    $scope.items = [{ name: "Mouse", price: "250", qty: "1" },
                 { name: "Keyboard", price: "500", qty: "1" },
                 { name: "RAM", price: "2000", qty: "1" },
                 { name: "CPU", price: "5000", qty: "1"}];

    $scope.selectItem = function (item) {
        $scope.selectedItem = item;
        CommonProp.setSelectedItems($scope.selectedItem);
        $location.path('/itemPage');

    };

});


myApp.service('CommonProp', function () {
    var selectedItems = '';
    //var Total = 0;

    return {
        getSelectedItems: function () {
            return selectedItems;
        },

        setSelectedItems: function (value) {
            selectedItems = value;
        }
    }
})